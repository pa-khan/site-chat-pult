$(document).ready(function($) {

	$('.input_tel input').mask('+7 (000) 000-00-00');
	
	$('.advantages__wrap_slider').slick()

	$('.mobile-btn').click(function() {
		$(this).toggleClass('mobile-btn_toggle');
		$('.nav').toggleClass('nav_toggle');
	});
});
